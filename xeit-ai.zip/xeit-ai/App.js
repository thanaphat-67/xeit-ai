import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, TextInput, FlatList, TouchableOpacity, Image, Alert, Modal, ScrollView,
  KeyboardAvoidingView, Platform, StyleSheet, ActivityIndicator, Switch, StatusBar as RNStatusBar,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as FileSystem from 'expo-file-system';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { load, save } from './src/storage';
import { loadModel, unloadModel, chat, stopGeneration, isLoaded, supportsVision } from './src/llm';
import { DIRS, ensureDirs, webSearch, generateImage, saveTextFile, shareFile } from './src/tools';

const C = { bg: '#0a0414', panel: '#160a2b', panel2: '#21113d', accent: '#8b3dff', text: '#f1e9ff', muted: '#9d8bbd', danger: '#ff5577' };
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const DEFAULTS = {
  systemPrompt: 'คุณคือ Xeit Ai ผู้ช่วย AI ที่ทำงานบนเครื่องของผู้ใช้ ตอบเป็นภาษาเดียวกับที่ผู้ใช้พิมพ์ ตอบกระชับ ตรงประเด็น และสุภาพ',
  nCtx: 4096, maxTokens: 768, temperature: 0.7,
  imageUrl: 'https://image.pollinations.ai/prompt/{prompt}?width=768&height=768&nologo=true&seed={seed}',
  webDefault: false, modelName: '', mmprojName: '',
};
const SUGGESTED = [
  ['Qwen2.5 1.5B (เล็ก เร็ว ~1GB)', 'https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf'],
  ['Qwen2.5 3B (ฉลาดขึ้น ~2GB)', 'https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf'],
  ['Llama 3.2 1B (~0.8GB)', 'https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf'],
];
const TAG_HELP = `
ความสามารถพิเศษ (ใช้เฉพาะเมื่อจำเป็น):
- สร้างไฟล์: <file name="ชื่อไฟล์.นามสกุล">เนื้อหาไฟล์</file>
- วาดภาพ: <image>English description of the image</image>
- จดจำข้อมูลผู้ใช้: <memory>ข้อมูลสั้นๆ</memory>
- ค้นเว็บ: <search>คำค้น</search> (แล้วหยุดตอบเพื่อรอผลค้นหา)`;

function parseTags(t) {
  const files = [], mem = [], imgs = [], srch = [];
  let clean = t.replace(/<file name="([^"]+)">([\s\S]*?)<\/file>/g, (_, n, c) => { files.push({ name: n, content: c.replace(/^\n|\n$/g, '') }); return `\n[ไฟล์: ${n}]\n`; });
  clean = clean.replace(/<memory>([\s\S]*?)<\/memory>/g, (_, c) => { mem.push(c.trim()); return ''; });
  clean = clean.replace(/<image>([\s\S]*?)<\/image>/g, (_, c) => { imgs.push(c.trim()); return ''; });
  clean = clean.replace(/<search>([\s\S]*?)<\/search>/g, (_, c) => { srch.push(c.trim()); return ''; });
  return { clean: clean.trim(), files, mem, imgs, srch };
}
const IMG_CMD = /^(\/img|\/image|วาด|สร้างรูป|สร้างภาพ|generate image|draw)\s*/i;

export default function App() {
  const [ready, setReady] = useState(false);
  const [screen, setScreen] = useState('chat');
  const [drawer, setDrawer] = useState(false);
  const [convos, setConvos] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [memories, setMemories] = useState([]);
  const [settings, setSettings] = useState(DEFAULTS);
  const [input, setInput] = useState('');
  const [pendingImg, setPendingImg] = useState(null);
  const [useWeb, setUseWeb] = useState(false);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [live, setLive] = useState('');
  const [modelLoaded, setModelLoaded] = useState(false);
  const [loadingModel, setLoadingModel] = useState(false);
  const listRef = useRef(null);
  const streamRef = useRef('');
  const timerRef = useRef(null);
  const stopRef = useRef(false);

  const active = convos.find((c) => c.id === activeId);

  useEffect(() => {
    (async () => {
      await ensureDirs();
      const [cv, mm, st, aid] = await Promise.all([load('convos', []), load('memories', []), load('settings', DEFAULTS), load('activeId', null)]);
      const s = { ...DEFAULTS, ...st };
      setConvos(cv); setMemories(mm); setSettings(s); setActiveId(aid); setUseWeb(s.webDefault);
      setReady(true);
      if (s.modelName) {
        try {
          const info = await FileSystem.getInfoAsync(DIRS.models + s.modelName);
          if (info.exists) await doLoadModel(s.modelName, s, true);
        } catch {}
      }
    })();
  }, []);
  useEffect(() => { if (ready) save('convos', convos); }, [convos, ready]);
  useEffect(() => { if (ready) save('memories', memories); }, [memories, ready]);
  useEffect(() => { if (ready) save('settings', settings); }, [settings, ready]);
  useEffect(() => { if (ready) save('activeId', activeId); }, [activeId, ready]);

  const patchSettings = (p) => setSettings((s) => ({ ...s, ...p }));

  async function doLoadModel(name, s = settings, silent = false) {
    setLoadingModel(true);
    try {
      await loadModel(DIRS.models + name, { nCtx: Number(s.nCtx) || 4096, mmproj: s.mmprojName ? DIRS.models + s.mmprojName : null });
      setModelLoaded(true); patchSettings({ modelName: name });
      if (!silent) Alert.alert('โหลดโมเดลแล้ว', name + (supportsVision() ? '\n(รองรับการอ่านรูป)' : ''));
    } catch (e) {
      setModelLoaded(false);
      Alert.alert('โหลดโมเดลไม่สำเร็จ', String(e.message || e));
    }
    setLoadingModel(false);
  }

  const updateConvo = (id, fn) => setConvos((cs) => cs.map((c) => (c.id === id ? { ...fn(c), updated: Date.now() } : c)));

  function scheduleLive() {
    if (timerRef.current) return;
    timerRef.current = setTimeout(() => { timerRef.current = null; setLive(streamRef.current); }, 90);
  }

  function toLLM(m) {
    if (m.role === 'user' && m.images && m.images.length && supportsVision())
      return { role: 'user', content: [{ type: 'text', text: m.content || 'อธิบายรูปนี้' }, ...m.images.map((u) => ({ type: 'image_url', image_url: { url: u } }))] };
    return { role: m.role, content: m.content + (m.role === 'user' && m.images && m.images.length && !supportsVision() ? '\n[ผู้ใช้แนบรูป แต่โมเดลนี้ยังไม่รองรับการอ่านรูป]' : '') };
  }
  function trim(arr) {
    const budget = (Number(settings.nCtx) || 4096) * 1.5 - 1200;
    let total = 0; const out = [];
    for (let i = arr.length - 1; i >= 0; i--) {
      const len = typeof arr[i].content === 'string' ? arr[i].content.length : 300;
      if (total + len > budget && out.length) break;
      total += len; out.unshift(arr[i]);
    }
    return out;
  }

  async function runModel(msgs, searchCtx) {
    const sys = settings.systemPrompt + TAG_HELP
      + (memories.length ? '\n\nข้อมูลที่จำไว้เกี่ยวกับผู้ใช้:\n' + memories.map((m) => '- ' + m.text).join('\n') : '')
      + (searchCtx ? '\n\nผลค้นหาเว็บล่าสุด (ใช้ตอบและบอกที่มา/ลิงก์):\n' + searchCtx : '');
    streamRef.current = '';
    return chat([{ role: 'system', content: sys }, ...trim(msgs.map(toLLM))], {
      onToken: (t) => { streamRef.current += t; scheduleLive(); },
      maxTokens: Number(settings.maxTokens) || 768, temperature: Number(settings.temperature) || 0.7,
    });
  }

  const fmtResults = (r) => r.map((x, i) => `[${i + 1}] ${x.title}\n${x.snippet}\n${x.url}`).join('\n\n');

  async function send() {
    const text = input.trim();
    if ((!text && !pendingImg) || busy) return;
    let id = activeId;
    if (!active) {
      id = uid();
      setConvos((cs) => [{ id, title: (text || 'รูปภาพ').slice(0, 30), messages: [], updated: Date.now() }, ...cs]);
      setActiveId(id);
    }
    const userMsg = { id: uid(), role: 'user', content: text, images: pendingImg ? [pendingImg] : [] };
    const history = [...(active ? active.messages : []), userMsg];
    updateConvo(id, (c) => ({ ...c, messages: history }));
    setInput(''); setPendingImg(null); setBusy(true); setLive(''); stopRef.current = false;
    // เพราะ updateConvo ทำงานกับ state ของ convo ที่เพิ่งสร้าง ให้ทำซ้ำแบบปลอดภัย
    setConvos((cs) => cs.some((c) => c.id === id) ? cs : cs);

    try {
      // 1) คำสั่งสร้างภาพ
      if (IMG_CMD.test(text) && !userMsg.images.length) {
        setStatus('🎨 กำลังสร้างภาพ...');
        const uri = await generateImage(text.replace(IMG_CMD, '') || text, settings.imageUrl);
        pushAssistant(id, { content: 'นี่คือภาพที่สร้างให้ครับ', images: [uri] });
        return;
      }
      if (!isLoaded()) { Alert.alert('ยังไม่ได้โหลดโมเดล', 'ไปที่ปุ่ม 📦 เพื่อดาวน์โหลด/นำเข้าและโหลดโมเดลก่อน'); pushAssistant(id, { content: '⚠️ ยังไม่ได้โหลดโมเดล กดปุ่ม 📦 ด้านบนก่อนนะครับ' }); return; }

      // 2) ค้นเว็บอัตโนมัติถ้าเปิดสวิตช์
      let sources = [], searchCtx = '';
      if (useWeb && text) {
        setStatus('🌐 กำลังค้นเว็บ...');
        sources = await webSearch(text);
        if (sources.length) searchCtx = fmtResults(sources);
      }
      setStatus('💭 กำลังคิด...');
      let out = await runModel(history, searchCtx);
      let p = parseTags(out);

      // 3) โมเดลขอค้นเว็บเอง
      if (p.srch.length && !searchCtx) {
        setStatus('🌐 กำลังค้นเว็บ: ' + p.srch[0]);
        sources = await webSearch(p.srch[0]);
        out = await runModel(history, sources.length ? fmtResults(sources) : 'ไม่พบผลการค้นหา');
        p = parseTags(out);
      }
      // 4) ไฟล์ / ภาพ / ความจำ
      const files = [];
      for (const f of p.files) { try { files.push({ name: f.name, path: await saveTextFile(f.name, f.content) }); } catch {} }
      const images = [];
      for (const ip of p.imgs.slice(0, 2)) { try { setStatus('🎨 กำลังสร้างภาพ...'); images.push(await generateImage(ip, settings.imageUrl)); } catch {} }
      if (p.mem.length) setMemories((m) => [...m, ...p.mem.map((t) => ({ id: uid(), text: t }))]);
      pushAssistant(id, { content: p.clean || '(ไม่มีคำตอบ)', files, images, sources });
    } catch (e) {
      pushAssistant(id, { content: '⚠️ เกิดข้อผิดพลาด: ' + String(e.message || e) });
    } finally {
      setBusy(false); setLive(''); setStatus('');
    }
  }
  const pushAssistant = (id, m) => updateConvo(id, (c) => ({ ...c, messages: [...c.messages, { id: uid(), role: 'assistant', images: [], files: [], sources: [], ...m }] }));

  function stop() { stopRef.current = true; stopGeneration(); }

  async function pickImage() {
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7 });
    if (!r.canceled) setPendingImg(r.assets[0].uri);
  }
  async function exportMsg(m) {
    try { await shareFile(await saveTextFile('xeit-' + Date.now() + '.md', m.content)); } catch (e) { Alert.alert('ผิดพลาด', String(e.message || e)); }
  }
  const newChat = () => { setActiveId(null); setDrawer(false); setScreen('chat'); };
  const delConvo = (c) => Alert.alert('ลบแชท', c.title, [{ text: 'ยกเลิก' }, { text: 'ลบ', style: 'destructive', onPress: () => { setConvos((cs) => cs.filter((x) => x.id !== c.id)); if (activeId === c.id) setActiveId(null); } }]);

  if (!ready) return <View style={[S.root, { justifyContent: 'center' }]}><ActivityIndicator color={C.accent} size="large" /></View>;

  // ---------- หน้าจอย่อย ----------
  if (screen === 'models') return <ModelsScreen {...{ settings, patchSettings, doLoadModel, loadingModel, modelLoaded, setModelLoaded }} back={() => setScreen('chat')} />;
  if (screen === 'memory') return <MemoryScreen {...{ memories, setMemories }} back={() => setScreen('chat')} />;
  if (screen === 'settings') return <SettingsScreen {...{ settings, patchSettings, setUseWeb }} back={() => setScreen('chat')} />;

  const data = active ? [...active.messages] : [];
  if (busy && live) data.push({ id: 'live', role: 'assistant', content: live, images: [], files: [], sources: [] });

  return (
    <KeyboardAvoidingView style={S.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <StatusBar style="light" />
      <View style={S.header}>
        <TouchableOpacity onPress={() => setDrawer(true)}><Text style={S.hbtn}>☰</Text></TouchableOpacity>
        <View style={{ flex: 1, marginHorizontal: 10 }}>
          <Text style={S.title}>Xeit Ai</Text>
          <Text style={S.sub} numberOfLines={1}>{loadingModel ? 'กำลังโหลดโมเดล...' : modelLoaded ? '● ' + settings.modelName : '○ ยังไม่ได้โหลดโมเดล'}</Text>
        </View>
        <TouchableOpacity onPress={() => setScreen('memory')}><Text style={S.hbtn}>🧠</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => setScreen('models')}><Text style={S.hbtn}>📦</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => setScreen('settings')}><Text style={S.hbtn}>⚙️</Text></TouchableOpacity>
      </View>

      {data.length === 0 ? (
        <View style={S.empty}>
          <Image source={require('./assets/icon.png')} style={{ width: 96, height: 96, borderRadius: 22, marginBottom: 14 }} />
          <Text style={S.emptyT}>สวัสดี! ผมคือ Xeit Ai</Text>
          <Text style={S.emptyS}>AI ที่รันบนเครื่องคุณเอง{'\n'}พิมพ์ "วาด แมวอวกาศ" เพื่อสร้างภาพ{'\n'}เปิด 🌐 เพื่อให้ค้นเว็บ • กด 📎 เพื่อแนบรูป</Text>
        </View>
      ) : (
        <FlatList ref={listRef} data={data} keyExtractor={(m) => m.id} contentContainerStyle={{ padding: 12 }}
          onContentSizeChange={() => listRef.current && listRef.current.scrollToEnd({ animated: false })}
          renderItem={({ item }) => <Bubble m={item} onExport={exportMsg} />} />
      )}

      {busy && <Text style={S.status}>{status} {live ? '' : '…'}</Text>}
      {pendingImg && (
        <View style={S.pending}>
          <Image source={{ uri: pendingImg }} style={{ width: 56, height: 56, borderRadius: 8 }} />
          <TouchableOpacity onPress={() => setPendingImg(null)}><Text style={{ color: C.danger, marginLeft: 10 }}>ลบรูป</Text></TouchableOpacity>
        </View>
      )}
      <View style={S.inputRow}>
        <TouchableOpacity onPress={pickImage}><Text style={S.ibtn}>📎</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => setUseWeb(!useWeb)}><Text style={[S.ibtn, { opacity: useWeb ? 1 : 0.35 }]}>🌐</Text></TouchableOpacity>
        <TextInput style={S.input} value={input} onChangeText={setInput} placeholder="พิมพ์ข้อความ..." placeholderTextColor={C.muted} multiline />
        {busy ? (
          <TouchableOpacity style={[S.send, { backgroundColor: C.danger }]} onPress={stop}><Text style={S.sendT}>■</Text></TouchableOpacity>
        ) : (
          <TouchableOpacity style={S.send} onPress={send}><Text style={S.sendT}>➤</Text></TouchableOpacity>
        )}
      </View>

      <Modal visible={drawer} animationType="slide" onRequestClose={() => setDrawer(false)}>
        <View style={S.root}>
          <View style={S.header}>
            <TouchableOpacity onPress={() => setDrawer(false)}><Text style={S.hbtn}>✕</Text></TouchableOpacity>
            <Text style={[S.title, { flex: 1, marginLeft: 12 }]}>ประวัติการแชท</Text>
          </View>
          <TouchableOpacity style={S.primary} onPress={newChat}><Text style={S.primaryT}>＋ แชทใหม่</Text></TouchableOpacity>
          <FlatList data={[...convos].sort((a, b) => b.updated - a.updated)} keyExtractor={(c) => c.id}
            ListEmptyComponent={<Text style={[S.emptyS, { marginTop: 30 }]}>ยังไม่มีประวัติ</Text>}
            renderItem={({ item }) => (
              <TouchableOpacity style={[S.row, item.id === activeId && { borderColor: C.accent }]} onPress={() => { setActiveId(item.id); setDrawer(false); }} onLongPress={() => delConvo(item)}>
                <Text style={{ color: C.text, fontSize: 15 }} numberOfLines={1}>{item.title}</Text>
                <Text style={{ color: C.muted, fontSize: 11, marginTop: 3 }}>{new Date(item.updated).toLocaleString()} • กดค้างเพื่อลบ</Text>
              </TouchableOpacity>
            )} />
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

function Bubble({ m, onExport }) {
  const me = m.role === 'user';
  return (
    <View style={[S.bubble, me ? S.me : S.ai]}>
      {(m.images || []).map((u) => <Image key={u} source={{ uri: u }} style={S.img} resizeMode="cover" />)}
      {!!m.content && <Text selectable style={{ color: C.text, fontSize: 15, lineHeight: 22 }}>{m.content}</Text>}
      {(m.files || []).map((f) => (
        <TouchableOpacity key={f.path} style={S.fileChip} onPress={() => shareFile(f.path)}><Text style={{ color: C.text }}>📄 {f.name} (แตะเพื่อเปิด/แชร์)</Text></TouchableOpacity>
      ))}
      {(m.sources || []).length > 0 && (
        <View style={{ marginTop: 8 }}>
          <Text style={{ color: C.muted, fontSize: 12 }}>แหล่งข้อมูล:</Text>
          {m.sources.map((s, i) => <Text key={i} style={{ color: '#b98cff', fontSize: 12 }} numberOfLines={1}>{i + 1}. {s.title}</Text>)}
        </View>
      )}
      {!me && m.id !== 'live' && !!m.content && (
        <TouchableOpacity onPress={() => onExport(m)}><Text style={{ color: C.muted, fontSize: 12, marginTop: 8 }}>💾 บันทึกเป็นไฟล์</Text></TouchableOpacity>
      )}
    </View>
  );
}

function Header({ title, back }) {
  return (
    <View style={S.header}>
      <TouchableOpacity onPress={back}><Text style={S.hbtn}>←</Text></TouchableOpacity>
      <Text style={[S.title, { marginLeft: 12 }]}>{title}</Text>
    </View>
  );
}

function ModelsScreen({ settings, patchSettings, doLoadModel, loadingModel, modelLoaded, setModelLoaded, back }) {
  const [files, setFiles] = useState([]);
  const [url, setUrl] = useState('');
  const [prog, setProg] = useState(null);
  const [copying, setCopying] = useState(false);
  const refresh = async () => {
    try {
      const names = await FileSystem.readDirectoryAsync(DIRS.models);
      const out = [];
      for (const n of names) { const i = await FileSystem.getInfoAsync(DIRS.models + n); out.push({ name: n, size: i.size || 0 }); }
      setFiles(out);
    } catch { setFiles([]); }
  };
  useEffect(() => { refresh(); }, []);
  const mb = (b) => (b / 1048576).toFixed(0) + ' MB';

  async function download(u) {
    const name = decodeURIComponent((u.split('?')[0].split('/').pop() || 'model.gguf'));
    try {
      setProg(0);
      const dl = FileSystem.createDownloadResumable(u, DIRS.models + name, {}, (p) => setProg(p.totalBytesExpectedToWrite ? p.totalBytesWritten / p.totalBytesExpectedToWrite : 0));
      await dl.downloadAsync();
      setProg(null); refresh();
    } catch (e) { setProg(null); Alert.alert('ดาวน์โหลดไม่สำเร็จ', String(e.message || e)); }
  }
  async function importFile() {
    const r = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: false, type: '*/*' });
    if (r.canceled) return;
    const a = r.assets[0];
    setCopying(true);
    try { await FileSystem.copyAsync({ from: a.uri, to: DIRS.models + a.name }); refresh(); }
    catch (e) { Alert.alert('นำเข้าไม่สำเร็จ', String(e.message || e)); }
    setCopying(false);
  }
  const tap = (f) => {
    if (/mmproj/i.test(f.name)) { patchSettings({ mmprojName: f.name }); Alert.alert('ตั้งเป็นตัวอ่านรูป (mmproj)', 'โหลดโมเดลหลักใหม่อีกครั้งเพื่อเปิดใช้งาน'); }
    else doLoadModel(f.name);
  };
  const del = (f) => Alert.alert('ลบไฟล์', f.name, [{ text: 'ยกเลิก' }, { text: 'ลบ', style: 'destructive', onPress: async () => { if (f.name === settings.modelName) { await unloadModel(); setModelLoaded(false); } await FileSystem.deleteAsync(DIRS.models + f.name, { idempotent: true }); refresh(); } }]);

  return (
    <View style={S.root}>
      <Header title="โมเดล AI (GGUF)" back={back} />
      <ScrollView contentContainerStyle={{ padding: 14 }}>
        <Text style={S.h2}>โมเดลในเครื่อง</Text>
        {loadingModel && <ActivityIndicator color={C.accent} style={{ marginVertical: 8 }} />}
        {files.length === 0 && <Text style={{ color: C.muted }}>ยังไม่มีโมเดล — ดาวน์โหลดหรือนำเข้าด้านล่าง</Text>}
        {files.map((f) => (
          <TouchableOpacity key={f.name} style={[S.row, f.name === settings.modelName && modelLoaded && { borderColor: C.accent }]} onPress={() => tap(f)} onLongPress={() => del(f)}>
            <Text style={{ color: C.text }} numberOfLines={1}>{/mmproj/i.test(f.name) ? '🖼️ ' : '🧩 '}{f.name}</Text>
            <Text style={{ color: C.muted, fontSize: 11 }}>{mb(f.size)}{f.name === settings.modelName && modelLoaded ? ' • กำลังใช้งาน' : ''}{f.name === settings.mmprojName ? ' • mmproj ที่เลือก' : ''} • แตะเพื่อโหลด • กดค้างเพื่อลบ</Text>
          </TouchableOpacity>
        ))}
        <Text style={S.h2}>นำเข้าไฟล์ .gguf จากเครื่อง</Text>
        <TouchableOpacity style={S.primary} onPress={importFile} disabled={copying}><Text style={S.primaryT}>{copying ? 'กำลังคัดลอก (ไฟล์ใหญ่ใช้เวลาสักพัก)...' : '📂 เลือกไฟล์'}</Text></TouchableOpacity>
        <Text style={S.h2}>ดาวน์โหลดจากลิงก์ (เช่น Hugging Face)</Text>
        <TextInput style={S.field} value={url} onChangeText={setUrl} placeholder="https://.../model.gguf" placeholderTextColor={C.muted} autoCapitalize="none" />
        <TouchableOpacity style={S.primary} onPress={() => url && download(url.trim())} disabled={prog !== null}><Text style={S.primaryT}>{prog !== null ? `ดาวน์โหลด ${(prog * 100).toFixed(0)}%` : '⬇️ ดาวน์โหลด'}</Text></TouchableOpacity>
        <Text style={S.h2}>แนะนำ</Text>
        {SUGGESTED.map(([n, u]) => (
          <TouchableOpacity key={u} style={S.row} onPress={() => prog === null && download(u)}><Text style={{ color: C.text }}>⬇️ {n}</Text></TouchableOpacity>
        ))}
        <Text style={{ color: C.muted, fontSize: 12, marginTop: 14 }}>
          เคล็ดลับ: ใช้ไฟล์ Q4_K_M ขนาด 1–4 GB สำหรับมือถือส่วนใหญ่ • ถ้าจะให้ AI อ่านรูปได้ ต้องใช้โมเดล vision (เช่น Qwen2-VL / SmolVLM / Gemma 3) พร้อมไฟล์ที่มีคำว่า mmproj — แตะไฟล์ mmproj ก่อน แล้วค่อยแตะโมเดลหลัก
        </Text>
      </ScrollView>
    </View>
  );
}

function MemoryScreen({ memories, setMemories, back }) {
  const [t, setT] = useState('');
  return (
    <View style={S.root}>
      <Header title="ความจำของ AI" back={back} />
      <View style={{ padding: 14, flex: 1 }}>
        <Text style={{ color: C.muted, marginBottom: 8 }}>ข้อมูลเหล่านี้จะถูกส่งให้ AI ทุกครั้งที่คุยกัน (AI สามารถเพิ่มเองได้เมื่อคุณบอกให้จำ)</Text>
        <View style={{ flexDirection: 'row' }}>
          <TextInput style={[S.field, { flex: 1, marginBottom: 0 }]} value={t} onChangeText={setT} placeholder="เช่น ฉันชื่อบิว ชอบกินเผ็ด" placeholderTextColor={C.muted} />
          <TouchableOpacity style={[S.send, { marginLeft: 8 }]} onPress={() => { if (t.trim()) { setMemories((m) => [...m, { id: uid(), text: t.trim() }]); setT(''); } }}><Text style={S.sendT}>＋</Text></TouchableOpacity>
        </View>
        <FlatList style={{ marginTop: 10 }} data={memories} keyExtractor={(m) => m.id}
          ListEmptyComponent={<Text style={{ color: C.muted, marginTop: 20 }}>ยังไม่มีความจำ</Text>}
          renderItem={({ item }) => (
            <View style={[S.row, { flexDirection: 'row', alignItems: 'center' }]}>
              <Text style={{ color: C.text, flex: 1 }}>{item.text}</Text>
              <TouchableOpacity onPress={() => setMemories((m) => m.filter((x) => x.id !== item.id))}><Text style={{ color: C.danger, fontSize: 18 }}>✕</Text></TouchableOpacity>
            </View>
          )} />
      </View>
    </View>
  );
}

function SettingsScreen({ settings, patchSettings, setUseWeb, back }) {
  const F = ({ label, k, num, multi }) => (
    <View>
      <Text style={S.h2}>{label}</Text>
      <TextInput style={[S.field, multi && { height: 110, textAlignVertical: 'top' }]} multiline={multi} value={String(settings[k])} keyboardType={num ? 'numeric' : 'default'}
        onChangeText={(v) => patchSettings({ [k]: num ? v.replace(/[^0-9.]/g, '') : v })} autoCapitalize="none" />
    </View>
  );
  return (
    <View style={S.root}>
      <Header title="ตั้งค่า" back={back} />
      <ScrollView contentContainerStyle={{ padding: 14 }}>
        <F label="System prompt (นิสัย/บทบาทของ AI)" k="systemPrompt" multi />
        <F label="Context length (n_ctx) — โหลดโมเดลใหม่เพื่อใช้ค่าใหม่" k="nCtx" num />
        <F label="ความยาวคำตอบสูงสุด (tokens)" k="maxTokens" num />
        <F label="Temperature (0.1 – 1.2)" k="temperature" num />
        <F label="URL สร้างภาพ ({prompt} และ {seed} จะถูกแทนที่)" k="imageUrl" multi />
        <View style={[S.row, { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 14 }]}>
          <Text style={{ color: C.text }}>เปิดค้นเว็บอัตโนมัติทุกข้อความ</Text>
          <Switch value={settings.webDefault} onValueChange={(v) => { patchSettings({ webDefault: v }); setUseWeb(v); }} />
        </View>
        <TouchableOpacity style={[S.primary, { backgroundColor: C.panel2, marginTop: 14 }]} onPress={() => Alert.alert('รีเซ็ตตั้งค่า', 'คืนค่าเริ่มต้น?', [{ text: 'ยกเลิก' }, { text: 'ตกลง', onPress: () => patchSettings({ ...DEFAULTS, modelName: settings.modelName, mmprojName: settings.mmprojName }) }])}><Text style={S.primaryT}>รีเซ็ตเป็นค่าเริ่มต้น</Text></TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const S = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, paddingTop: RNStatusBar.currentHeight || 40 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.panel2 },
  hbtn: { color: C.text, fontSize: 22, marginHorizontal: 7 },
  title: { color: C.text, fontSize: 18, fontWeight: '700' },
  sub: { color: C.muted, fontSize: 11 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  emptyT: { color: C.text, fontSize: 20, fontWeight: '700', marginBottom: 8 },
  emptyS: { color: C.muted, textAlign: 'center', lineHeight: 22 },
  bubble: { maxWidth: '88%', padding: 12, borderRadius: 16, marginBottom: 10 },
  me: { alignSelf: 'flex-end', backgroundColor: C.accent, borderBottomRightRadius: 4 },
  ai: { alignSelf: 'flex-start', backgroundColor: C.panel, borderBottomLeftRadius: 4 },
  img: { width: 240, height: 240, borderRadius: 12, marginBottom: 8 },
  fileChip: { backgroundColor: C.panel2, padding: 10, borderRadius: 10, marginTop: 8 },
  status: { color: C.muted, paddingHorizontal: 16, paddingBottom: 4, fontSize: 12 },
  pending: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingBottom: 6 },
  inputRow: { flexDirection: 'row', alignItems: 'flex-end', padding: 10, borderTopWidth: 1, borderTopColor: C.panel2 },
  ibtn: { fontSize: 22, marginHorizontal: 5, marginBottom: 8, color: C.text },
  input: { flex: 1, maxHeight: 120, backgroundColor: C.panel, color: C.text, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 9, fontSize: 15, marginHorizontal: 4 },
  send: { backgroundColor: C.accent, width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  sendT: { color: '#fff', fontSize: 18 },
  row: { backgroundColor: C.panel, padding: 12, borderRadius: 12, marginHorizontal: 0, marginVertical: 4, borderWidth: 1, borderColor: 'transparent' },
  primary: { backgroundColor: C.accent, padding: 13, borderRadius: 12, alignItems: 'center', margin: 4 },
  primaryT: { color: '#fff', fontWeight: '700' },
  h2: { color: C.text, fontWeight: '700', marginTop: 16, marginBottom: 6 },
  field: { backgroundColor: C.panel, color: C.text, borderRadius: 10, padding: 11, marginBottom: 8 },
});
