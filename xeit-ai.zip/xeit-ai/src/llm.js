import { initLlama } from 'llama.rn';

let ctx = null;
let vision = false;
const clean = (p) => p.replace('file://', '');

export const isLoaded = () => !!ctx;
export const supportsVision = () => vision;

export async function unloadModel() {
  if (ctx) { try { await ctx.release(); } catch {} }
  ctx = null; vision = false;
}

export async function loadModel(path, { nCtx = 4096, mmproj = null } = {}) {
  await unloadModel();
  ctx = await initLlama({ model: clean(path), n_ctx: nCtx, n_gpu_layers: 0, use_mlock: false });
  if (mmproj) {
    try { vision = !!(await ctx.initMultimodal({ path: clean(mmproj), use_gpu: false })); }
    catch { vision = false; }
  }
}

export async function chat(messages, { onToken, maxTokens = 768, temperature = 0.7 } = {}) {
  if (!ctx) throw new Error('ยังไม่ได้โหลดโมเดล');
  const res = await ctx.completion(
    {
      messages,
      n_predict: maxTokens,
      temperature,
      top_p: 0.9,
      stop: ['</s>', '<|end|>', '<|im_end|>', '<|eot_id|>', '<end_of_turn>'],
    },
    (d) => onToken && onToken(d.token)
  );
  return res.text;
}

export const stopGeneration = () => { try { ctx && ctx.stopCompletion(); } catch {} };
