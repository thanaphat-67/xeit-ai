import AsyncStorage from '@react-native-async-storage/async-storage';
export const load = async (k, d) => {
  try { const v = await AsyncStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; }
};
export const save = (k, v) => AsyncStorage.setItem(k, JSON.stringify(v)).catch(() => {});
