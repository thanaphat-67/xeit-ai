import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';

const DOC = FileSystem.documentDirectory;
export const DIRS = { models: DOC + 'models/', images: DOC + 'images/', files: DOC + 'files/' };
export const ensureDirs = async () => {
  for (const d of Object.values(DIRS)) {
    try { await FileSystem.makeDirectoryAsync(d, { intermediates: true }); } catch {}
  }
};

const UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36';
const strip = (s) =>
  s.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"')
   .replace(/&#x27;|&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
const decodeLink = (h) => {
  const m = h.match(/uddg=([^&]+)/);
  if (m) { try { return decodeURIComponent(m[1]); } catch {} }
  return h.startsWith('//') ? 'https:' + h : h;
};

export async function webSearch(q) {
  const out = [];
  try {
    const r = await fetch('https://html.duckduckgo.com/html/?q=' + encodeURIComponent(q), { headers: { 'User-Agent': UA } });
    const html = await r.text();
    const re = /<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
    let m;
    while ((m = re.exec(html)) && out.length < 5) out.push({ url: decodeLink(m[1]), title: strip(m[2]), snippet: strip(m[3]) });
  } catch {}
  if (!out.length) {
    try {
      const r = await fetch('https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=4&srsearch=' + encodeURIComponent(q));
      const j = await r.json();
      for (const s of j.query.search)
        out.push({ url: 'https://en.wikipedia.org/wiki/' + encodeURIComponent(s.title.replace(/ /g, '_')), title: s.title, snippet: strip(s.snippet) });
    } catch {}
  }
  return out;
}

export async function generateImage(prompt, template) {
  const url = template
    .replace('{prompt}', encodeURIComponent(prompt))
    .replace('{seed}', String(Math.floor(Math.random() * 1e6)));
  const dest = DIRS.images + Date.now() + '.jpg';
  const res = await FileSystem.downloadAsync(url, dest);
  if (res.status !== 200) throw new Error('สร้างภาพไม่สำเร็จ (' + res.status + ')');
  return res.uri;
}

export async function saveTextFile(name, content) {
  const safe = name.replace(/[^\w.\-ก-๙ ]/g, '_') || 'file.txt';
  const path = DIRS.files + safe;
  await FileSystem.writeAsStringAsync(path, content);
  return path;
}

export async function shareFile(path) {
  if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(path);
}
